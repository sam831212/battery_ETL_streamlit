import{aP as u,aQ as m,g as h}from"./index.C1NIn1Y2.js";var e,r;function W(){if(r)return e;r=1;var t=u(),a=m(),i=a(function(s,g,n,o){t(s,g,n,o)});return e=i,e}var c=W();const v=h(c);export{v as m};
