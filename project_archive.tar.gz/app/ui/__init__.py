"""
Streamlit UI components for the Battery ETL Dashboard
"""
