"""
Battery ETL Dashboard - Application module
"""
