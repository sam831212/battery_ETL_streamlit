"""
Utility functions for the Battery ETL Dashboard
"""
