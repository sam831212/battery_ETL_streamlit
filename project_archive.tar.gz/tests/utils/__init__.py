"""
Test module for utility functions
"""